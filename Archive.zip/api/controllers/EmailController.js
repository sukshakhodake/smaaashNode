// module.exports = {

//     sendMail: function (req, res) {
//         var callback = function (err, response) {

//         }
//         Enquiry.saveData(req.body, callback);

//     }
// };