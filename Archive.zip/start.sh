sudo rm -rf .tmp
sudo nodemon app.js